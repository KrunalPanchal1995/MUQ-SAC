#!/usr/bin/perl -w
#Wayne K. Metcalfe
#v5 Minor bug fixes, mainly related to duplicate plog reactions
#v4 optimises lnA instead of a. Before I had used a ln form but solved for a
#v3 uses a ln form plus converts all parameters to 1E5,1.0 and 1.0. If the resultant fit fails it retries using
#the high pressure initial guess
#v2 uses a ln form of the arrhenius equation
#This code removes the PLOG formulation and replaces it with a rate constant
#fitted at the user defined pressure via a logarithmic interpolation.
use strict;
use 5.01;
use List::Util 'min';
use List::Util 'max';
use File::Copy;

#global variables definition
my @env_var;
my $gnu_check = 0;
my $x;
my $mech_name;
my $pres;
my @mech;
my @plog_data;
my $y;
my $reaction;
my @line;
my %pressure_k_list;
my @pressure_list;
my $use_pres1;
my $plus1percent;
my $minus1percent;
my @mech1;
my @chem_eqn;
my $plog_count;
my $lowp;
my $highp;
my @pressure_list_sort;
my $low_reaction;
my @low_reaction;
my $a1;
my $b1;
my $c1;
my $high_reaction;
my @high_reaction;
my $a2;
my $b2;
my $c2;
my $T;
my @lowk;
my @highk;
my $z;
my @newk;
my @fitlog;
my $newA;
my $newA_error;
my $newB;
my $newB_error;
my $newC;
my $newC_error;
my $figname;
my @errors;
##############################

##############################
#Checking if gnuplot is installed
@env_var = %ENV;


foreach (@env_var){
	if ($_ =~ /gnuplot/){
		$gnu_check++;
	}
}
if ($gnu_check == 0){
		print <<INPUT;

ERROR!!!!!!!!!!!!!!!!!!!!!!!!!

Gnuplot must be installed on your system and the home directory listed in the Environmental variables.
Gnuplot is used to perform the nonlinear fits and analyse the results.

For download: http://www.gnuplot.info/

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

INPUT
		<STDIN>;
		die;
}
##############################

##############################
#Reading keywords
if (@ARGV > 0){
	$x = 0;
	foreach (@ARGV){
		$x++;
		if ($_ =~ /-c/i) {
			$mech_name = $ARGV[$x];
		}
		elsif ($_ =~ /-p/i) {
			$pres = $ARGV[$x];
		}
	}
}
else {
	print <<INPUT;

ERROR!!!!!!!!!!!!!!!!!!!!!!!!!

User input required!!

-c chemistry filename (REQUIRED!)
-p pressured in atm (REQUIRED!)

To run: perl PLOG_replace_vx -c chem.inp -p 12.2

Note: x = current version.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

INPUT
	<STDIN>;
	die;
}
##############################

##############################
#####print out selections and fail if required input is not provided
print "\nPLOG Replacement Code\n\n";
print "----------------------------------------\n";
die "ERROR!! You must define a chemistry file: e.g. -c chem.inp\n"
unless defined$mech_name;
print "Chemsitry file: 	$mech_name\n";
die "ERROR!! $mech_name not present in working directory!!.\n"
	unless -e $mech_name;

die "ERROR!! You must define a Pressure\n"
unless defined$pres;
print "Desired Pressure: 	$pres (atm)\n";
##############################

##############################
#Check that the pressure is nonzero
unless ($pres > 0){
		print <<INPUT;

ERROR!!!!!!!!!!!!!!!!!!!!!!!!!

Pressure selected is zero or negative: User must provide a postive pressure!!

INPUT
	die;
}
##############################

##############################
#remove all unwanted whitespce from mechanism
print "\nCreating a clean versions of the chemistry file...\n";
open(CHEM, "$mech_name");
my @input = <CHEM>;
close CHEM;
open(TMP, ">mech_clean.tmp");

foreach (@input){
	tidy_chem($_);
	if(/\S/){
	print TMP;
	}
}
close TMP;
@input = ();
##############################

##############################
#finding all the PLOG rates, one group at a time
open (CHEM, "mech_clean.tmp");
@mech = <CHEM>;
close CHEM;
@mech1 = @mech;

$x = 0;
$y = 0;
while ($x <= $#mech){
	if ($mech[$x] =~ /^PLOG\//i){
# 		sleep 2;
		$plog_count++;
		$y = $x;
		if ($mech[$x-1] =~ /^DUP/i){
			push (@plog_data, $mech[$x-2]);
			push (@plog_data, $mech[$x-1]);
		}
		else {
			push (@plog_data, $mech[$x-1]);
		}
		until ($mech[$y] !~ /^PLOG\//i){
			push (@plog_data, $mech[$y]);
			$x = $y;
			$y++;
		}
##############################

##############################
#making a hash of P and k
#making an array of available pressures
		$reaction = shift(@plog_data);
		chomp$reaction;
		@chem_eqn = split /\s/, $reaction;
		print "\n\nFitting PLOG $plog_count: $chem_eqn[0]\n\n";
		foreach (@plog_data){
			$_ =~ s/\///g;
			if($_ =~ /PLOG\s+(\S+)\s+(\S+\s+\S+\s+\S+)\s+/i){
				$pressure_k_list{$1} = $2;
				push (@pressure_list, $1);
			}
		}
##############################

##############################
#determine if input pressure equals any PLOG defined pressures +/- 1 percent
		foreach (@pressure_list){
			$plus1percent = $_*1.01;
			$minus1percent = $_*0.99;
			if ($_ == $pres || $pres >= $minus1percent and $pres <= $plus1percent){
				$use_pres1 = $_;
				last;
			}
		}
##############################

##############################
#determine if the user defined pressure is outside the range of the PLOG description
#if below the min, assign the min. If above the max, assign the max.
		unless(defined$use_pres1){
			if ($pres < min(@pressure_list)){
				$use_pres1 = min(@pressure_list);
			}
			elsif ($pres > max(@pressure_list)){
				$use_pres1 = max(@pressure_list);
			}
		}
##############################

#############################
#if $use_pres has been defined at this point there is no interpolation needed.
#This selects the appropriate PLOG rate and writes it with the opposing reaction
		if (defined$use_pres1){
			foreach (@mech1){
				if ($_ =~ /\Q$reaction\E/){
					$_ =~ s/\Q$reaction\E/$chem_eqn[0] $pressure_k_list{$use_pres1} !!$use_pres1 atm rate!!/;
					last;
				}
			}
			print "PLOG \# $plog_count: $chem_eqn[0]	$pressure_k_list{$use_pres1} !!$use_pres1 atm rate!!\n";
		}
##############################

##############################
#if $use_pres is still undefined at this point an interpolation is needed:
#first sort pressure list from low to high, more than likely will already be like this
#find the low and high pressures for use in the interpolation.
		unless (defined$use_pres1){
			$use_pres1 = $pres;
			@pressure_list_sort = sort{$a<=>$b}@pressure_list;#numeric sort, low to high
			#@pressure_list_sort = sort(@pressure_list);#ascii sort, low to high
			foreach (@pressure_list_sort){
				if ($_ < $pres){
					$lowp = $_;
				}
				if ($_ > $pres){
					$highp = $_;
					last;
				}
			}
##############################

##############################
#get the appropriate rate constants form the hash and seperate the a, n, ea
			$low_reaction = $pressure_k_list{$lowp};
			@low_reaction = split /\s+/, $low_reaction;
			$c1 = pop(@low_reaction);
			$b1 = pop(@low_reaction);
			$a1 = pop(@low_reaction);
			
			$high_reaction = $pressure_k_list{$highp};
			@high_reaction = split /\s+/, $high_reaction;
			$c2 = pop(@high_reaction);
			$b2 = pop(@high_reaction);
			$a2 = pop(@high_reaction);
##############################

##############################
#calculate both high and low k's from 500-2000K
			for ($T = 500; $T <= 2000; $T+=100){
				push (@lowk, $a1*($T**$b1)*exp(-$c1/(1.987*$T)));
				push (@highk, $a2*($T**$b2)*exp(-$c2/(1.987*$T)));
			}
##############################

##############################
#performs the interpolation, pushes values to array
			$z = 0;
			foreach (@lowk){
				push (@newk, exp(log($_)+((log($highk[$z]) - log($_)) * ( (log($use_pres1) - log($lowp)) / (log($highp) - log($lowp))))));
				$z++;
			}
##############################

##############################
#takes figname from reaction name
			$figname = $chem_eqn[0];
			$figname =~ s/<=>/=/g;
##############################

##############################
#writes input files for gnuplot
			open (FITDAT, ">fit_data_ln.tmp");
			open (FITDAT1, ">fit_data.tmp");
			print FITDAT "\#T K, interpolated ln k\n";
			$z = 0;
			for ($T = 500; $T <= 2000; $T+=100){
				print FITDAT "$T ".log($newk[$z])."\n";
				print FITDAT1 "$T $newk[$z]\n";
				$z++
			}
			close FITDAT;
			close FITDAT1;
			if ($plog_count < 10){
				copy ("fit_data.tmp", "k_0$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.txt");
			}
			else {
				copy ("fit_data.tmp", "k_$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.txt");
			}
			

			open GNU_INP, (">fit.tmp");
			print GNU_INP "f1(x) = a+(b*$b1)*log(x)+(-(c*$c1)/(1.987*x))\n";
			print GNU_INP "FIT_LIMIT = 1e-10\n";
			print GNU_INP "FIT_MAXITER = 5000\n";
			#print GNU_INP "FIT_LAMBDA_FACTOR = 10.0\n";
			print GNU_INP "fit f1(x) 'fit_data_ln.tmp' using 1:2 via \"guess.tmp\"";
			close GNU_INP;
			
			open GUESS, (">guess.tmp");
			print GUESS "a = ".log($a1)."\n";
			print GUESS "b = 1\n";
			print GUESS "c = 1";
			close GUESS;
##############################
#perform fit with gnuplot and extracts the results
			unlink ("fit.log");
			system ("gnuplot.exe -e \"load 'fit.tmp'\"");
			open FITLOG ,("fit.log");
			@fitlog = <FITLOG>;
			close FITLOG;
			
			foreach (@fitlog){
				if ($_ =~ /a\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
					$newA = $1;
					$newA_error = $2;
				}
				if ($_ =~ /b\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
					$newB = $1;
					$newB_error = $2;
				}
				if ($_ =~ /c\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
					$newC = $1;
					$newC_error = $2;
				}
			}
##############################

##############################
#Convert back to original magnitudes
			$newA = exp($newA);
			$newB = $newB*$b1;
			$newC = $newC*($c1);
##############################

##############################
#if A becomes negative, repeat using HP initial parameters
			if ($newA < 0){
# 				if ($plog_count < 10){
# 					copy ("fit_data.tmp", "k_0$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.txt");
# 				}
# 				else {
# 					copy ("fit_data.tmp", "k_$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.txt");
# 				}

				open GNU_INP, (">fit.tmp");
				print GNU_INP "f1(x) = a+(b*$b2)*log(x)+(-(c*$c2)/(1.987*x))\n";
				print GNU_INP "FIT_LIMIT = 1e-10\n";
				print GNU_INP "FIT_MAXITER = 5000\n";
				#print GNU_INP "FIT_LAMBDA_FACTOR = 10.0\n";
				print GNU_INP "fit f1(x) 'fit_data_ln.tmp' using 1:2 via \"guess.tmp\"";
				close GNU_INP;
				
				open GUESS, (">guess.tmp");
				print GUESS "a = ".log($a2)."\n";
				print GUESS "b = 1\n";
				print GUESS "c = 1";
				close GUESS;
##############################

##############################
#perform fit with gnuplot and extracts the results
				unlink ("fit.log");
				system ("gnuplot.exe -e \"load 'fit.tmp'\"");
				open FITLOG ,("fit.log");
				@fitlog = <FITLOG>;
				close FITLOG;
				
				foreach (@fitlog){
					if ($_ =~ /a\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
						$newA = $1;
						$newA_error = $2;
					}
					if ($_ =~ /b\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
						$newB = $1;
						$newB_error = $2;
					}
					if ($_ =~ /c\s+=\s+(\S+)\s+\S+\s+\S+\s+\((\S+)\)/){
						$newC = $1;
						$newC_error = $2;
					}
				}
##############################

##############################
#Convert back to original magnitudes
				$newA = exp($newA);
				$newB = $newB*$b2;
				$newC = $newC*($c2);
			}
##############################

##############################
#catches errors
			unless (defined$newA){
				push (@errors, $plog_count);
				push (@errors, $figname);
			}
			if ($newA < 0){
				push (@errors, $plog_count);
				push (@errors, $figname);
			}
##############################

##############################
#Control number of signficant figures:
			$newA = sprintf "%10.3E", $newA;
			$newB = sprintf "%10.3f", $newB;
			$newC = sprintf "%10.1f", $newC;
#############################

##############################
#Replaces the appropriate reaction
			foreach (@mech1){
				if ($_ =~ /\Q$reaction\E/){
					$_ =~ s/\Q$reaction\E/$chem_eqn[0] $newA $newB $newC !!PLOG $plog_count: $use_pres1 atm rate. A error:+\/-$newA_error, B error:+\/-$newB_error, C error:+\/-$newC_error!! /;
					last;
				}
			}
			print "\nPLOG \#: $plog_count $chem_eqn[0]	$newA $newB $newC !!$use_pres1 atm rate.\n        A error:+/-$newA_error, B error:+/-$newB_error, C error:+/-$newC_error!!\n";
##############################

##############################
#Plots up the comparison of low p rate, high p rate, interpolated rate and it's fit
			if ($plog_count < 10){
				open (FIGURE, ">k_0$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.tmp");
			}
			else {
				open FIGURE, (">k_$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.tmp");
			}
			print FIGURE "set terminal jpeg\n";
			if ($plog_count < 10){
				print FIGURE "set output \"k_0$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.jpg\"\n";
			}
			else{
				print FIGURE "set output \"k_$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.jpg\"\n";
			}
			print FIGURE "set title \"$figname $use_pres1 atm\"\n";
			print FIGURE "set key inside left top vertical Right noreverse enhanced autotitles nobox\n";
			print FIGURE "set xlabel 'T K'\n";
			print FIGURE "set ylabel 'k'\n";
			print FIGURE "set logscale y 10\n";
			print FIGURE "plot \"fit_data.tmp\" u 1:2 title \'$use_pres1 atm\' with p 1, $newA*(x**$newB)*exp(-$newC/(1.987*x)) title 'New Fit' with l 1, $a1*(x**$b1)*exp(-$c1/(1.987*x)) title \'$lowp atm k\' with l 2, $a2*(x**$b2)*exp(-$c2/(1.987*x)) title \'$highp atm k\' with l 3";
			close FIGURE;
			
			if ($plog_count < 10){
				system ("gnuplot.exe -e \"load \'k_0$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.tmp\'");
			}
			else{
				system ("gnuplot.exe -e \"load \'k_$plog_count"."_"."$figname"."_"."$use_pres1"."_atm.tmp\'");
			}
##############################
	}
##############################

##############################
#As these are global variables, they need to be emptied before moving into the next PLOG set.
		@plog_data = ();
		%pressure_k_list = ();
		@pressure_list = ();
		$use_pres1 = undef;
		$lowp = undef;
		$highp = undef;
		$low_reaction = undef;
		@low_reaction = ();
		$a1 = undef;
		$b1 = undef;
		$c1 = undef;
		$high_reaction = undef;
		@high_reaction = ();
		$a2 = undef;
		$b2 = undef;
		$c2 = undef;
		@lowk = ();
		@highk = ();
		@newk = ();
		@fitlog = ();
		$newA = undef;
		$newA_error = undef;
		$newB = undef;
		$newB_error = undef;
		$newC = undef;
		$newC_error = undef;
##############################

	}
	$x++;
}
print "\nTotal Number of PLOG descriptions:	$plog_count\n\n";
##############################
#The main loop of the program is finished and the new mechanism is contained in @mech1.
#This loop comments out all the PLOG rates. I decided to leave them in the file as it makes it
#much easier to spot any bugs.
foreach (@mech1){
	$_ =~ s/PLOG/!PLOG/i;
}
##############################

##############################
#Writes the desired mechanism to an output file
open (FINAL, ">$mech_name"."_$pres"."_atm.inp");
print FINAL "!!!!Mechanism only valid at $pres atm!!!!!\n";
print FINAL "\n!All $plog_count PLOG descriptions have been replaced.\n\n";
if (@errors > 0){
	$x = 0;
	print FINAL "!!!WARNING!!!\n";
	while ($x <= $#errors){
		print FINAL "!PLOG $errors[$x]: $errors[$x+1]		Fit failed to converge. Please fit manually with the interpolated values provided.\n";
		$x+=2;
	}
	print FINAL "!!!!!!!!!!!!!\n\n";
}
print FINAL "! - If the desired pressure is available in a specific PLOG description\n";
print FINAL "!   or is within 1% of one of the values, the listed rate has been used.\n";
print FINAL "! - If the desired pressure is outside the range of the PLOG description,\n";
print FINAL "!   the appropriate minimum or maximum has been adopted.\n\n";
print FINAL @mech1;
close FINAL;
##############################

##############################
#make a new directory for the images and data files
my $dir = $mech_name.'_'.$pres.'_atm_rate_plots';
mkdir $dir or warn "Cannot make $dir directory: $!";
my @jpgs = glob "k*.jpg";
foreach(@jpgs){
	move("$_", "$dir");
}
my @datafiles = glob "k*.txt";
foreach (@datafiles){
	move("$_", "$dir");
}
#############################

##############################
#deletes the tmp files
my @tmp = glob "*.tmp";
foreach (@tmp){
	unlink;
}
unlink ("fit.log");
##############################

##############################
#subroutine
sub tidy_chem{
	my $n =shift;
	$_ =~ s/!.*//;
	$_ =~ s/\t+/ /g;
	$_ =~ s/^\s+//g;
	$_ =~ s/ *\/ */\/ /g;
	$_ =~ s/\s+$/\n/g;
	$_ =~ s/\s*<=>\s*/<=>/g;
	$_ =~ s/\s*=\s*/=/g;
	$_ =~ s/\s*=>\s*/=>/g;
	$_ =~ s/<=>/=/g;
	$_ =~ s/=/<=>/g;
	$_ =~ s/<=>>/=>/g;
	$_ =~ s/\s+\+\s+/\+/g;
	$_ =~ s/ *\/ */\/ /g;
	$_ =~ s/ +/ /g;
#	$_ =~ s/^rev.*//g or s/^REV.*//g;
	return $n
}