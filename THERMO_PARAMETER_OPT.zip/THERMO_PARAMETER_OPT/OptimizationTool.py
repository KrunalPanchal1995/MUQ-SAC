import numpy as np
from solution import Solution
from scipy.optimize import minimize 
from scipy import optimize as spopt
import numpy as np
import time
from matplotlib import pyplot as plt
import matplotlib.animation as animation
from matplotlib import style
import pygad
import matplotlib as mpl
mpl.use('Agg')
style.use("fivethirtyeight")
import os
from scipy.optimize import rosen, differential_evolution
from scipy.optimize import NonlinearConstraint, Bounds
from scipy.optimize import shgo
from scipy.optimize import BFGS
import pickle

class OptimizationTool(object):
	def __init__(self,
		target_list=None,frequency = None,opt_method = "GA"):
		
		self.target_list = target_list
		self.objective = 0
		self.frequency = frequency
		self.count = 0
		self.opt_method = opt_method
	
	def obj_func_of_selected_PRS_thermo(self,Z):	
		
		self.count +=1
		string_x = "{self.count},"
		for i in Z:
			string_x+=f"{i},"
		string_x+="\n"
		note = open("guess_values.txt","+a").write(string_x)

		###Algorithm:
		#1] Get the guess values into saperate bins corresponding to species
			# eg: Z_{Ar: Low} = [x1,x2,x3,x4,x5] -> store x5 in self.unsrt[Ar:High].first
			# pass Z_{Ar: Low} to DECODER, get X_{Ar:Low}
		V_of_Z = {}
		count = 0
		for ind,speciesID in enumerate(self.unsrt):
			if self.unsrt[speciesID].a1_star is None or np.all(self.unsrt[speciesID].a1_star) == None:
				species_name = self.unsrt[speciesID].species
				lim = self.unsrt[speciesID].temp_limit
				p_o = self.species_dict[species_name][lim]
				zeta_max = self.zeta_dict[species_name][lim]
				#print(zeta_max)
				
				cov = self.cov_dict[species_name][lim]
				Z_species = Z[count:count+len(p_o)]
				T_low = self.T[count:count+len(p_o)]
				
				Cp_T = []
				for index in range(5):
					t = T_low[index]
					Theta = np.asarray([t/t,t,t**2,t**3,t**4])
					p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
					Cp_T.append(Theta.dot(p_))
				x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_low),species_name,self.count,tag="Low")
				count+=len(p_o)
				V_of_Z[speciesID] = x_species
				for spec in self.unsrt:
					if self.unsrt[spec].species == species_name:
						self.unsrt[spec].a1_star = Z_species
						self.unsrt[spec].a2_star = Z_species[-1]
						self.unsrt[spec].Cp_T_mid_star = Cp_T[-1]
			else:
				species_name = self.unsrt[speciesID].species
				lim = self.unsrt[speciesID].temp_limit
				p_o = self.species_dict[species_name][lim]
				zeta_max = self.zeta_dict[species_name][lim]
				cov = self.cov_dict[species_name][lim]
				Z_species = Z[count:count+len(p_o)-1]
				Cp_T = [self.unsrt[speciesID].Cp_T_mid_star]  ##Start with mid Cp value 1000k
				T_high = self.T[count:count+len(p_o)-1]
				for index in range(4):  ### Start from the next point after 1000 K
					t = T_high[index]
					Theta = np.asarray([t/t,t,t**2,t**3,t**4])
					p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
					Cp_T.append(Theta.dot(p_))
				x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_high),species_name,self.count,tag="High")
				count+=len(p_o)-1
				V_of_Z[speciesID] = x_species
				for spec in self.unsrt:
					if self.unsrt[spec].species == species_name:
						self.unsrt[spec].a1_star = None
						self.unsrt[spec].a2_star = None
						self.unsrt[spec].Cp_T_mid_star = None
		
		string = ""
		V = []
		for spec in self.unsrt:
			V.extend(list(V_of_Z[spec]))
			for k in V_of_Z[spec]:
				string+=f"{k},"
			#x_transformed.extend(temp)
		string+=f"\n"
		V = np.asarray(V)
		#print(V)
		zeta_file = open("zeta_guess_values.txt","+a").write(string)	
		#2] Use X_{Ar:Low} to generate obj. function value from response surface
			#eta_{case_0}= eta([X_{Ar:Low},X_{Ar:High},X_{H2:Low},...])
			#Make sure V_{case_0} = [X_{Ar:Low},X_{Ar:High},X_{H2:Low},...] is in the order of self.unsrt
		"""
		Just for simplicity
		"""
		x = V
		
		obj = 0.0
		rejected_PRS = []
		rejected_PRS_index = []
		target_value = []
		target_stvd = []
		direct_target_value = []
		direct_target_stvd = []
		target_value_2 = []
		case_stvd = []
		case_systematic_error = []
		response_value = []
		response_stvd = []	
		target_weights = []	
		COUNT_Tig = 0
		COUNT_Fls = 0
		COUNT_All = 0	
		COUNT_Flw = 0
		frequency = {}
		diff = []
		diff_2 = []
		diff_3 = {}
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Tig +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					#print(val)
					#val,grad = case.evaluateResponse(x)
					f_exp = np.log(case.observed*10)
					#print(f_exp,val)
					#w = 1/(np.log(case.std_dvtn*10))
					w_ = case.std_dvtn/case.observed
					w = 1/w_
					diff.append((val-f_exp)*w)
					#diff.append((val - f_exp)/f_exp)
					diff_2.append(val - f_exp)
					diff_3[case.uniqueID] = (val-f_exp)/f_exp
					response_value.append(val)
					#response_stvd.append(grad)
					#diff.append(val - np.log(case.observed*10))
					target_value.append(np.log(case.observed*10))
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn*10)))
					case_stvd.append(np.log(case.std_dvtn*10))
					case_systematic_error.append(abs(np.log(case.observed*10)-val))
					#target_weights.append(dataset_weights)				
				elif case.target == "Fls":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Fls +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = np.exp(self.ResponseSurfaces[i].evaluate(x))
					response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					diff.append((val - f_exp)*w)
					#response_stvd.append(grad)
					target_value.append(case.observed)
					target_value_2.append(case.observed)
					target_stvd.append(1/(case.std_dvtn))
					case_stvd.append(case.std_dvtn)
					case_systematic_error.append(abs(case.observed)-val)
					#target_weights.append(dataset_weights)	
				elif case.target == "Flw":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Flw +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					diff.append((val - f_exp)*w)
					#response_stvd.append(grad)
					target_value.append(np.log(case.observed))
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn)+abs(np.log(case.observed)-val)))
					case_stvd.append(np.log(case.std_dvtn))
					case_systematic_error.append(abs(np.log(case.observed)-val))
					#target_weights.append(dataset_weights)	
			
		
		diff = np.asarray(diff)
		multiplicating_factors = []
		#multiplicating_factors = np.asarray(target_weights)*np.asarray(target_stvd)
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					multiplicating_factors.append(1/COUNT_Tig)
		
				elif case.target == "Fls":
					multiplicating_factors.append(1/COUNT_Fls)
		
		multiplicating_factors= np.asarray(multiplicating_factors)		
		#Giving all datapoints equal weights
		#multiplicating_factor = 1/COUNT_All
		
		for i,dif in enumerate(diff):
			#obj+= multiplicating_factors[i]*(dif)**2
			#obj+= multiplicating_factor*(dif)**2
			#obj+= multiplicating_factors[i]*(dif)**2
			obj+=dif**2		
		
		Diff_3 = open("Dataset_based_obj","+a").write(f"{diff_3}\n")
		get_opt = open("Objective.txt","+a").write(f"{obj}\n")
		string_v = f"{self.count},"
		for i in x:
			string_v+=f"{x},"
		string_v+="\n"
		note = open("guess_values_TRANSFORMED.txt","+a").write(string_v)
		#string_response="#CaseID,Obs,Xvector...\n"
		#for i in range(len(target_value)):
		#	string_response+=f"{target_value[i]},"
		string_response = ""
		for i in range(len(response_value)):
			string_response+=f"{response_value[i]},"
		string_response+="\n"	
		get_target_value = open("response_values.txt","+a").write(string_response)
		#print(obj)
		#if self.count > 3:
		#	raise AssertionError("Stop!")
		return obj
	
	def fitness_function_for_T_DIPENDENT(self):
		global obj_func_of_selected_PRS_thermo
		def obj_func_of_selected_PRS_thermo(Z,solution_idx):	
		
			self.count +=1
			string_x = "{self.count},"
			for i in Z:
				string_x+=f"{i},"
			string_x+="\n"
			note = open("guess_values.txt","+a").write(string_x)

			###Algorithm:
			#1] Get the guess values into saperate bins corresponding to species
				# eg: Z_{Ar: Low} = [x1,x2,x3,x4,x5] -> store x5 in self.unsrt[Ar:High].first
				# pass Z_{Ar: Low} to DECODER, get X_{Ar:Low}
			V_of_Z = {}
			count = 0
			for ind,speciesID in enumerate(self.unsrt):
				if self.unsrt[speciesID].a1_star is None or np.all(self.unsrt[speciesID].a1_star) == None:
					species_name = self.unsrt[speciesID].species
					lim = self.unsrt[speciesID].temp_limit
					p_o = self.species_dict[species_name][lim]
					zeta_max = self.zeta_dict[species_name][lim]
					#print(zeta_max)
					
					cov = self.cov_dict[species_name][lim]
					Z_species = Z[count:count+len(p_o)]
					T_low = self.T[count:count+len(p_o)]
					
					Cp_T = []
					for index in range(5):
						t = T_low[index]
						Theta = np.asarray([t/t,t,t**2,t**3,t**4])
						p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
						Cp_T.append(Theta.dot(p_))
					x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_low),species_name,self.count,tag="Low")
					count+=len(p_o)
					V_of_Z[speciesID] = x_species
					for spec in self.unsrt:
						if self.unsrt[spec].species == species_name:
							self.unsrt[spec].a1_star = Z_species
							self.unsrt[spec].a2_star = Z_species[-1]
							self.unsrt[spec].Cp_T_mid_star = Cp_T[-1]
				else:
					species_name = self.unsrt[speciesID].species
					lim = self.unsrt[speciesID].temp_limit
					p_o = self.species_dict[species_name][lim]
					zeta_max = self.zeta_dict[species_name][lim]
					cov = self.cov_dict[species_name][lim]
					Z_species = Z[count:count+len(p_o)-1]
					Cp_T = [self.unsrt[speciesID].Cp_T_mid_star]  ##Start with mid Cp value 1000k
					T_high = self.T[count:count+len(p_o)-1]
					for index in range(4):  ### Start from the next point after 1000 K
						t = T_high[index]
						Theta = np.asarray([t/t,t,t**2,t**3,t**4])
						p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
						Cp_T.append(Theta.dot(p_))
					x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_high),species_name,self.count,tag="High")
					count+=len(p_o)-1
					V_of_Z[speciesID] = x_species
					for spec in self.unsrt:
						if self.unsrt[spec].species == species_name:
							self.unsrt[spec].a1_star = None
							self.unsrt[spec].a2_star = None
							self.unsrt[spec].Cp_T_mid_star = None
			
			string = ""
			V = []
			for spec in self.unsrt:
				V.extend(list(V_of_Z[spec]))
				for k in V_of_Z[spec]:
					string+=f"{k},"
				#x_transformed.extend(temp)
			string+=f"\n"
			V = np.asarray(V)
			#print(V)
			zeta_file = open("zeta_guess_values.txt","+a").write(string)	
			#2] Use X_{Ar:Low} to generate obj. function value from response surface
				#eta_{case_0}= eta([X_{Ar:Low},X_{Ar:High},X_{H2:Low},...])
				#Make sure V_{case_0} = [X_{Ar:Low},X_{Ar:High},X_{H2:Low},...] is in the order of self.unsrt
			"""
			Just for simplicity
			"""
			x = V
			
			obj = 0.0
			rejected_PRS = []
			rejected_PRS_index = []
			target_value = []
			target_stvd = []
			direct_target_value = []
			direct_target_stvd = []
			target_value_2 = []
			case_stvd = []
			case_systematic_error = []
			response_value = []
			response_stvd = []	
			target_weights = []	
			COUNT_Tig = 0
			COUNT_Fls = 0
			COUNT_All = 0	
			COUNT_Flw = 0
			frequency = {}
			diff = []
			diff_2 = []
			diff_3 = {}
			for i,case in enumerate(self.target_list):
				if self.ResponseSurfaces[i].selection == 1:	
					if case.target == "Tig":
						if case.d_set in frequency:
							frequency[case.d_set] += 1
						else:
							frequency[case.d_set] = 1
						COUNT_All +=1
						COUNT_Tig +=1
						#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
						#dataset_weights = (1/COUNT_All)
						
						val = self.ResponseSurfaces[i].evaluate(x)
						#print(val)
						#val,grad = case.evaluateResponse(x)
						f_exp = np.log(case.observed*10)
						#print(f_exp,val)
						#w = 1/(np.log(case.std_dvtn*10))
						w_ = case.std_dvtn/case.observed
						w = 1/w_
						diff.append((val-f_exp)*w)
						#diff.append((val - f_exp)/f_exp)
						diff_2.append(val - f_exp)
						diff_3[case.uniqueID] = (val-f_exp)/f_exp
						response_value.append(val)
						#response_stvd.append(grad)
						#diff.append(val - np.log(case.observed*10))
						target_value.append(np.log(case.observed*10))
						target_value_2.append(np.log(case.observed))
						target_stvd.append(1/(np.log(case.std_dvtn*10)))
						case_stvd.append(np.log(case.std_dvtn*10))
						case_systematic_error.append(abs(np.log(case.observed*10)-val))
						#target_weights.append(dataset_weights)				
					elif case.target == "Fls":
						if case.d_set in frequency:
							frequency[case.d_set] += 1
						else:
							frequency[case.d_set] = 1
						COUNT_All +=1
						COUNT_Fls +=1
						#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
						#dataset_weights = (1/COUNT_All)
						
						val = np.exp(self.ResponseSurfaces[i].evaluate(x))
						response_value.append(val)
						f_exp = case.observed
						w = 1/(case.std_dvtn)
						diff.append((val - f_exp)*w)
						#response_stvd.append(grad)
						target_value.append(case.observed)
						target_value_2.append(case.observed)
						target_stvd.append(1/(case.std_dvtn))
						case_stvd.append(case.std_dvtn)
						case_systematic_error.append(abs(case.observed)-val)
						#target_weights.append(dataset_weights)	
					elif case.target == "Flw":
						if case.d_set in frequency:
							frequency[case.d_set] += 1
						else:
							frequency[case.d_set] = 1
						COUNT_All +=1
						COUNT_Flw +=1
						#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
						#dataset_weights = (1/COUNT_All)
						
						val = self.ResponseSurfaces[i].evaluate(x)
						response_value.append(val)
						f_exp = case.observed
						w = 1/(case.std_dvtn)
						diff.append((val - f_exp)*w)
						#response_stvd.append(grad)
						target_value.append(np.log(case.observed))
						target_value_2.append(np.log(case.observed))
						target_stvd.append(1/(np.log(case.std_dvtn)+abs(np.log(case.observed)-val)))
						case_stvd.append(np.log(case.std_dvtn))
						case_systematic_error.append(abs(np.log(case.observed)-val))
						#target_weights.append(dataset_weights)	
				
			
			diff = np.asarray(diff)
			multiplicating_factors = []
			#multiplicating_factors = np.asarray(target_weights)*np.asarray(target_stvd)
			for i,case in enumerate(self.target_list):
				if self.ResponseSurfaces[i].selection == 1:	
					if case.target == "Tig":
						multiplicating_factors.append(1/COUNT_Tig)
			
					elif case.target == "Fls":
						multiplicating_factors.append(1/COUNT_Fls)
			
			multiplicating_factors= np.asarray(multiplicating_factors)		
			#Giving all datapoints equal weights
			#multiplicating_factor = 1/COUNT_All
			
			for i,dif in enumerate(diff):
				#obj+= multiplicating_factors[i]*(dif)**2
				#obj+= multiplicating_factor*(dif)**2
				#obj+= multiplicating_factors[i]*(dif)**2
				obj+=dif**2		
			
			Diff_3 = open("Dataset_based_obj","+a").write(f"{diff_3}\n")
			get_opt = open("Objective.txt","+a").write(f"{obj}\n")
			string_v = f"{self.count},"
			for i in x:
				string_v+=f"{x},"
			string_v+="\n"
			note = open("guess_values_TRANSFORMED.txt","+a").write(string_v)
			#string_response="#CaseID,Obs,Xvector...\n"
			#for i in range(len(target_value)):
			#	string_response+=f"{target_value[i]},"
			string_response = ""
			for i in range(len(response_value)):
				string_response+=f"{response_value[i]},"
			string_response+="\n"	
			get_target_value = open("response_values.txt","+a").write(string_response)
			#print(obj)
			#if self.count > 3:
			#	raise AssertionError("Stop!")
			fitness = 1.0 / (np.abs((obj) - 0) + 0.000001)
			#fitness = 1.0 / (np.abs((obj) - 0))
			record =open("samplefile.txt","+a").write(f"{self.ga_instance.generations_completed},{self.count},{self.objective},{fitness}\n")
			
			return fitness
		return obj_func_of_selected_PRS_thermo
	
	def obj_func_of_selected_PRS(self,x):	
		
		self.count +=1
		note = open("guess_values.txt","+a").write(f"{self.count},{x}\n")
		
		kappa_curve = {}
		count = 0
		for i in self.rxn_index:
			temp = []
			for j in range(len(self.T)):
				temp.append(x[count])
				count += 1
			#trial = [temp[0],(temp[0]+temp[1])/2,temp[1]]
			Kappa = self.kappa_0[i] + temp*(self.kappa_max[i]-self.kappa_0[i])
			kappa_curve[i] = np.asarray(Kappa).flatten()
			
		
		zeta = {}
		for rxn in self.rxn_index:
			zeta[rxn] = self.unsrt[rxn].getZeta_typeA(kappa_curve[rxn])
	
		x_transformed = []
		string = ""
		for rxn in self.rxn_index:
			temp = list(zeta[rxn])
			for k in temp:
				string+=f"{k},"
			x_transformed.extend(temp)
		string+=f"\n"
		x_transformed = np.asarray(x_transformed)
		zeta_file = open("zeta_guess_values.txt","+a").write(string)
		"""
		Just for simplicity
		"""
		x = x_transformed
		
		obj = 0.0
		rejected_PRS = []
		rejected_PRS_index = []
		target_value = []
		target_stvd = []
		direct_target_value = []
		direct_target_stvd = []
		target_value_2 = []
		case_stvd = []
		case_systematic_error = []
		response_value = []
		response_stvd = []	
		target_weights = []	
		COUNT_Tig = 0
		COUNT_Fls = 0
		COUNT_All = 0	
		COUNT_Flw = 0
		frequency = {}
		diff = []
		diff_2 = []
		diff_3 = {}
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Tig +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					#print(val)
					#val,grad = case.evaluateResponse(x)
					f_exp = np.log(case.observed*10)
					#w = 1/(np.log(case.std_dvtn*10))
					w_ = case.std_dvtn/case.observed
					w = 1/w_
					diff.append((val-f_exp)*w)
					#diff.append((val - f_exp)/f_exp)
					diff_2.append(val - f_exp)
					diff_3[case.uniqueID] = (val-f_exp)/f_exp
					response_value.append(val)
					#response_stvd.append(grad)
					#diff.append(val - np.log(case.observed*10))
					target_value.append(np.log(case.observed*10))
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn*10)))
					case_stvd.append(np.log(case.std_dvtn*10))
					case_systematic_error.append(abs(np.log(case.observed*10)-val))
					#target_weights.append(dataset_weights)				
				elif case.target == "Fls":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Fls +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = np.exp(self.ResponseSurfaces[i].evaluate(x))
					response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					diff.append((val - f_exp)*w)
					#response_stvd.append(grad)
					target_value.append(case.observed)
					target_value_2.append(case.observed)
					target_stvd.append(1/(case.std_dvtn))
					case_stvd.append(case.std_dvtn)
					case_systematic_error.append(abs(case.observed)-val)
					#target_weights.append(dataset_weights)	
				elif case.target == "Flw":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Flw +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					diff.append((val - f_exp)*w)
					#response_stvd.append(grad)
					target_value.append(np.log(case.observed))
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn)+abs(np.log(case.observed)-val)))
					case_stvd.append(np.log(case.std_dvtn))
					case_systematic_error.append(abs(np.log(case.observed)-val))
					#target_weights.append(dataset_weights)	
			
		
		diff = np.asarray(diff)
		multiplicating_factors = []
		#multiplicating_factors = np.asarray(target_weights)*np.asarray(target_stvd)
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					multiplicating_factors.append(1/COUNT_Tig)
		
				elif case.target == "Fls":
					multiplicating_factors.append(1/COUNT_Fls)
		
		multiplicating_factors= np.asarray(multiplicating_factors)		
		#Giving all datapoints equal weights
		#multiplicating_factor = 1/COUNT_All
		
		for i,dif in enumerate(diff):
			#obj+= multiplicating_factors[i]*(dif)**2
			#obj+= multiplicating_factor*(dif)**2
			#obj+= multiplicating_factors[i]*(dif)**2
			obj+=dif**2		
		
		Diff_3 = open("Dataset_based_obj","+a").write(f"{diff_3}\n")
		get_opt = open("Objective.txt","+a").write(f"{obj}\n")
		note = open("guess_values_TRANSFORMED.txt","+a").write(f"{self.count},{x}\n")
		get_target_value = open("response_values.txt","+a").write(f"\t{target_value},{response_value}\n")
		
		
		return obj
	def plot_DATA(self,x):	
		kappa_curve = {}
		count = 0
		for i in self.rxn_index:
			temp = []
			for j in range(len(self.T)):
				temp.append(x[count])
				count += 1
			#trial = [temp[0],(temp[0]+temp[1])/2,temp[1]]
			Kappa = self.kappa_0[i] + temp*(self.kappa_max[i]-self.kappa_0[i])
			kappa_curve[i] = np.asarray(Kappa).flatten()
			
		
		zeta = {}
		for rxn in self.rxn_index:
			zeta[rxn] = self.unsrt[rxn].getZeta_typeA(kappa_curve[rxn])
	
		x_transformed = []
		string = ""
		for rxn in self.rxn_index:
			temp = list(zeta[rxn])
			for k in temp:
				string+=f"{k},"
			x_transformed.extend(temp)
		string+=f"\n"
		x_transformed = np.asarray(x_transformed)
		zeta_file = open("zeta_guess_values.txt","+a").write(string)
		"""
		Just for simplicity
		"""
		x = x_transformed
		
		obj = 0.0
		rejected_PRS = []
		rejected_PRS_index = []
		target_value = []
		target_stvd = []
		direct_target_value = []
		direct_target_stvd = []
		target_value_2 = []
		case_stvd = []
		case_systematic_error = []
		response_value = []
		response_stvd = []	
		target_weights = []	
		COUNT_Tig = 0
		COUNT_Fls = 0
		COUNT_All = 0	
		COUNT_Flw = 0
		frequency = {}
		diff = []
		diff_2 = []
		diff_3 = {}
		VALUE = []
		EXP = []
		CASE = []
		TEMPERATURE = []
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":					
					t = case.temperature
					val = self.ResponseSurfaces[i].evaluate(x)
					f_exp = np.log(case.observed*10)
					VALUE.append(np.exp(val)/10)
					EXP.append(np.exp(f_exp)/10)
					CASE.append(case.dataSet_id)
					TEMPERATURE.append(t)				
				elif case.target == "Fls":
					t = case.temperature
					val = np.exp(self.ResponseSurfaces[i].evaluate(x))
					f_exp = case.observed
					VALUE.append(val)
					EXP.append(f_exp)	
					CASE.append(case.dataSet_id)
					TEMPERATURE.append(t)
		
		return VALUE,EXP,CASE,TEMPERATURE
	
	def _obj_function(self,x):
		kappa_curve = {}
		count = 0
		for i in self.rxn_index:
			temp = []
			for j in range(len(self.T)):
				temp.append(x[count])
				count += 1
			Kappa = self.kappa_0[i] + temp*(self.kappa_max[i]-self.kappa_0[i])
			kappa_curve[i] = np.asarray(Kappa).flatten()
			
		
		zeta = {}
		for rxn in self.rxn_index:
			zeta[rxn] = self.unsrt[rxn].getZeta_typeA(kappa_curve[rxn])
	
		x_transformed = []
		string = ""
		for rxn in self.rxn_index:
			temp = list(zeta[rxn])
			for k in temp:
				string+=f"{k},"
			x_transformed.extend(temp)
		string+=f"\n"
		x_transformed = np.asarray(x_transformed)
		zeta_file = open("zeta_guess_values.txt","+a").write(string)
		"""
		Just for simplicity
		"""
		x = x_transformed
		
		obj = 0.0
		rejected_PRS = []
		rejected_PRS_index = []
		target_value = []
		target_stvd = []
		direct_target_value = []
		direct_target_stvd = []
		target_value_2 = []
		case_stvd = []
		case_systematic_error = []
		response_value = []
		response_stvd = []	
		target_weights = []	
		COUNT_Tig = 0
		COUNT_Fls = 0
		COUNT_All = 0	
		COUNT_Flw = 0
		frequency = {}
		
		num_params = len(x)
		num_expts = len(self.target_list)
		f = np.empty(num_expts)
		df = np.zeros((num_expts,num_params))
		inv_covar = np.linalg.cholesky(4*np.eye(len(x)))
		initial_guess = np.zeros(len(x))
		#f[0:num_params] = np.dot(inv_covar,(x - initial_guess))
		#df[0:num_params,0:num_params] = inv_covar
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Tig +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					#response_value.append(val)
					f_exp = np.log(case.observed*10)
					w = 1/(np.log(case.std_dvtn*10))
					f[i] = (val - f_exp)*w
					#print(self.ResponseSurfaces[i].Jacobian(x))
					df[i,:] = np.asarray(self.ResponseSurfaces[i].Jacobian(x))*w
					#raise AssertionError("Optimization about to happen")
					#response_stvd.append(grad)
					#target_weights.append(dataset_weights)				
				elif case.target == "Fls":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Fls +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = np.exp(self.ResponseSurfaces[i].evaluate(x))
					#response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					f[i] = (val - f_exp)*w
					df[i,:] = np.asarray(self.ResponseSurfaces[i].Jacobian(x))*w
					#response_stvd.append(grad)
					#target_weights.append(dataset_weights)	
				elif case.target == "Flw":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Flw +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					#response_value.append(val)
					f_exp = case.observed
					w = 1/(case.std_dvtn)
					f[i] = (val - f_exp)*w
					df[i,:] = np.asarray(self.ResponseSurfaces[i].Jacobian(x))*w
					#response_stvd.append(grad)
					
					#target_weights.append(dataset_weights)	
			
		return f,df
	def _obj_func(self,x):
		string = ""
		for i in x:
			string+=f"{i},"
		string+=f"\n"
		#x_transformed = np.asarray(x_transformed)
		zeta_file = open("zeta_guess_values.txt","+a").write(string)
		"""
		Just for simplicity
		"""
		
		obj = 0.0
		rejected_PRS = []
		rejected_PRS_index = []
		target_value = []
		target_stvd = []
		direct_target_value = []
		direct_target_stvd = []
		target_value_2 = []
		case_stvd = []
		case_systematic_error = []
		response_value = []
		response_stvd = []	
		target_weights = []	
		COUNT_Tig = 0
		COUNT_Fls = 0
		COUNT_All = 0	
		COUNT_Flw = 0
		frequency = {}
		
		
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Tig +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					#print(val)
					#val,grad = case.evaluateResponse(x)
					response_value.append(val)
					#response_stvd.append(grad)
					target_value.append(np.log(case.observed*10))
					
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn*10)))
					case_stvd.append(case.std_dvtn/case.observed)
					case_systematic_error.append(abs(np.log(case.observed*10)-val))
					#target_weights.append(dataset_weights)				
				elif case.target == "Fls":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Fls +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = np.exp(self.ResponseSurfaces[i].evaluate(x))
					response_value.append(val)
					#response_stvd.append(grad)
					target_value.append(case.observed)
					target_value_2.append(case.observed)
					target_stvd.append(1/(case.std_dvtn))
					case_stvd.append(case.std_dvtn)
					case_systematic_error.append(abs(case.observed)-val)
					#target_weights.append(dataset_weights)	
				elif case.target == "Flw":
					if case.d_set in frequency:
						frequency[case.d_set] += 1
					else:
						frequency[case.d_set] = 1
					COUNT_All +=1
					COUNT_Flw +=1
					#dataset_weights = (1/len(self.frequency))*float(self.frequency[case.d_set])
					#dataset_weights = (1/COUNT_All)
					
					val = self.ResponseSurfaces[i].evaluate(x)
					response_value.append(val)
					#response_stvd.append(grad)
					target_value.append(np.log(case.observed))
					target_value_2.append(np.log(case.observed))
					target_stvd.append(1/(np.log(case.std_dvtn)+abs(np.log(case.observed)-val)))
					case_stvd.append(np.log(case.std_dvtn))
					case_systematic_error.append(abs(np.log(case.observed)-val))
					#target_weights.append(dataset_weights)	
			
		self.count +=1
		diff = np.asarray(response_value)-np.asarray(target_value)
		multiplicating_factors = []
		#multiplicating_factors = np.asarray(target_weights)*np.asarray(target_stvd)
		for i,case in enumerate(self.target_list):
			if self.ResponseSurfaces[i].selection == 1:	
				if case.target == "Tig":
					multiplicating_factors.append(1/COUNT_Tig)
		
				elif case.target == "Fls":
					multiplicating_factors.append(0.05*(1/COUNT_Fls))
		
		multiplicating_factors= np.asarray(multiplicating_factors)		
		#Giving all datapoints equal weights
		#multiplicating_factor = 1/COUNT_All
		
		for i,dif in enumerate(diff):
			#obj+= multiplicating_factors[i]*(dif)**2
			#obj+= multiplicating_factor*(dif)**2
			obj+= multiplicating_factors[i]*(dif)**2
						
		
		note = open("guess_values.txt","+a").write(f"{self.count},{x}\n")
		get_target_value = open("response_values.txt","+a").write(f"\t{target_value},{response_value}\n")
		get_opt = open("Objective.txt","+a").write(f"{obj}\n")
		return obj
	
		
	def run_optimization_with_selected_PRS(self,Unsrt_data,ResponseSurfaces,Input_data):
	   
		self.unsrt = Unsrt_data
		self.ResponseSurfaces = ResponseSurfaces
		self.Input_data = Input_data
		algorithm = Input_data["Type"]["Algorithm"]
		self.rxn_index = np.asarray([rxn for rxn in Unsrt_data]).flatten()
		self.init_guess = np.zeros(len(self.rxn_index))	
		bounds = tuple([(-1,1) for _ in self.init_guess ])
		
		if Input_data["Stats"]["Design_of_PRS"] == "A-facto":
		
			opt_output = minimize(self._obj_func,
					    self.init_guess,
					    bounds=bounds,
					    method='L-BFGS-B',  # Replace 'algorithm' with specific method if known
					    options={"maxiter": 500000}  # Replace 'maxfev' with 'maxiter'
					)
			#opt_output = minimize(self._obj_func,self.init_guess,bounds=bounds,method=algorithm,options={"maxiter":500000})
			print(opt_output)
			optimal_parameters = np.asarray(opt_output.x)
			optimal_parameters_zeta = np.asarray(opt_output.x)
			cov = []
		
		else:
			self.rxn_index = []
			self.kappa_0 = {}
			self.kappa_max = {}
			
			for rxn in self.unsrt:
				self.rxn_index.append(rxn)
			self.T = np.linspace(300,2500,3)
			#self.init_guess = np.zeros(len(self.T[1:])*len(self.rxn_index))
			self.init_guess = np.zeros(len(self.T)*len(self.rxn_index))
			bounds = tuple([(-1,1) for _ in self.init_guess ])
			
			theta = np.array([self.T/self.T,np.log(self.T),-1/self.T])
			#self.theta_inv = np.linalg.inv(theta.T)
			
			for rxn in self.rxn_index:
				#self.activeParameters[rxn] = self.unsrt[rxn].activeParameters
				self.kappa_0[rxn] = self.unsrt[rxn].getNominal(self.T)
				self.kappa_max[rxn] = self.unsrt[rxn].getKappaMax(self.T)
			
			start = time.time()
			opt_output = minimize(self.obj_func_of_selected_PRS,self.init_guess,bounds=bounds,method='Powell',options={"maxfev":500000})
			stop = time.time()
			final=print(f"Time taken for optimization {stop-start}")
			#opt_output = spopt.root(self._obj_function,self.init_guess,method="lm",jac = True)
			print(opt_output)
			optimal_parameters = np.asarray(opt_output.x)
			#residuals,final_jac= self._obj_function(optimal_parameters)
			#icov = np.dot(final_jac.T,final_jac)
			#cov = np.linalg.inv(icov)
			#raise AssertionError("Optimization done!")
			"""
			Finding the optimal parameters
			"""
			print("<<<<<<<<<<<<<<<<FOUND BEST SOLUTION>>>>>>>>>>>>>>>>>>>>>\n")
			#print(f"{solution}")
			"""
			-----------------------------------------
			Transformation 1.0 of the optimal parameters:
			-----------------------------------------
			
				 X =  __ln(kappa/kappa_0)____
				   ln(kappa_max/kappa_0)
				
			  ln(kappa) - ln(kappa_0) = X*[ln(kappa_max) - ln(kappa_0)]
			  
			  ln(kappa) = ln(kappa_0) + X*[ln(kappa_max) - ln(kappa_0)]
				 
			-----------------------------------------
			Transformation 2.0 of the optimal parameters:
			-----------------------------------------
			
				 X =  ___kappa__-__kappa_0__
					kappa_max - kappa_0
				
			  kappa - kappa_0 = X*[kappa_max - kappa_0]
			  
			  kappa = kappa_0 + X*[kappa_max - kappa_0]
			
			
			"""
			kappa_curve = {}
			count = 0
			
			for rxn in self.rxn_index:
				temp = []
				for j in range(len(self.T)):
					temp.append(optimal_parameters[count])
					count += 1
				#Kappa = np.exp(np.log(kappa_0[i]) + temp*(np.log(kappa_max[i])-np.log(kappa_0[i])))
				#For searching class-C type curves
				#trial = [temp[0],(temp[0]+temp[1])/2,temp[1]]
				Kappa = self.kappa_0[rxn] + temp*(self.kappa_max[rxn]-self.kappa_0[rxn])
				
				#print(Kappa)
				kappa_curve[rxn] = np.asarray(Kappa).flatten()
				
	
			zeta = {}
			#print(gen)
			for rxn in self.rxn_index:
				zeta[rxn] = self.unsrt[rxn].getZeta_typeA(kappa_curve[rxn])
			optimal_parameters_zeta = []
			for rxn in self.rxn_index:
				temp = list(zeta[rxn])
				optimal_parameters_zeta.extend(temp)
			#########################
			### For plotting purposes
			########################
			delta_n = {}
			p = {}
			V_opt = {}
			V = {}#Populating V for unshuffled portion of the design matrix
			ch = {}
			nominal = {}
			p_max = {}
			p_min = {}
			theta = {}
			Temp = {}
			d_n = {}
			for index,rxn in enumerate(self.unsrt):
				ch[rxn] = self.unsrt[rxn].cholskyDeCorrelateMat
				nominal[rxn] = self.unsrt[rxn].nominal
				p = self.unsrt[rxn].nominal
				p_max[rxn] = self.unsrt[rxn].P_max
				p_min[rxn] = self.unsrt[rxn].P_min
				theta[rxn] = self.unsrt[rxn].Theta
				Temp[rxn] = self.unsrt[rxn].temperatures
				Tp = self.unsrt[rxn].temperatures
				#Tp = np.linspace(300,2500,50)
				Theta_p = np.array([Tp/Tp,np.log(Tp),-1/(Tp)])
				#P_max = P + np.asarray(np.dot(cov,zet)).flatten();
				#P_min = P - np.asarray(np.dot(cov,zet)).flatten();
				kmax = Theta_p.T.dot(p_max[rxn])
				kmin = Theta_p.T.dot(p_min[rxn])
				ka_o = Theta_p.T.dot(nominal[rxn])
				p_zet = p + np.asarray(np.dot(ch[rxn],zeta[rxn])).flatten();
				k =  Theta_p.T.dot(p_zet)
				fig = plt.figure()
				plt.title(str(rxn))
				plt.xlabel(r"1000/T\K$^{-1}$")
				plt.ylabel(r"$log_{10}(k)$ / $s^{-1}$ or $log_{10}$(k) / $cm^{3}\,molecule^{-1}\,s^{-1}$")
				plt.plot(1/Tp,kmax,'k--',label="Uncertainty limits")
				plt.plot(1/Tp,kmin,'k--')
				plt.plot(1/Tp,ka_o,'b-',label='Prior rate constant')
				plt.plot(1/Tp,k,'r-',label='Optimized rate constant')
				d_n[rxn]=abs(p[1]-p_zet[1])
				plt.savefig("Plots/reaction_"+str(rxn)+".png",bbox_inches='tight')
			optimal_parameters_zeta = np.asarray(optimal_parameters_zeta)	
			cov = []
			print(d_n)
			
			###############
			# Printing the optimal parameters
			###############
			#Optimal parameters
			#cases
			#response surface
			VALUE,EXP,CASE,TEMPERATURE = self.plot_DATA(optimal_parameters)
			DATASET = set(CASE)
			
			for case_id in DATASET:
				file_ =open(str(case_id)+".csv","+w")
				STRING = "T(k)\tf_exp\tValue\n"
				for i,case in enumerate(CASE):
					if case ==case_id:
						STRING+=f"{TEMPERATURE[i]}\t{EXP[i]}\t{VALUE[i]}\n" 
				file_.write(STRING)
		
						
		return np.asarray(optimal_parameters),np.asarray(optimal_parameters_zeta),cov
		
		
	def run_optimization_with_selected_PRS_thermo(self,unsrt_data,ResponseSurfaces,Input_data):
		
		self.unsrt = unsrt_data
		self.ResponseSurfaces = ResponseSurfaces
		self.Input_data = Input_data
		algorithm = Input_data["Type"]["Algorithm"]
		self.species_index = np.asarray([species for species in unsrt_data]).flatten()
		self.species_index = np.asarray([species for species in unsrt_data]).flatten()
		self.init_guess = np.ones(len(self.species_index))	
		bounds = tuple([(-1,1) for _ in self.init_guess ])
		
		if Input_data["Stats"]["Design_of_PRS"] == "A-facto":
		
			opt_output = minimize(self._obj_func,
					    self.init_guess,
					    bounds=bounds,
					    method='L-BFGS-B',  # Replace 'algorithm' with specific method if known
					    options={"maxiter": 500000}  # Replace 'maxfev' with 'maxiter'
					)
			#opt_output = minimize(self._obj_func,self.init_guess,bounds=bounds,method=algorithm,options={"maxiter":500000})
			print(opt_output)
			optimal_parameters = np.asarray(opt_output.x)
			optimal_parameters_zeta = np.asarray(opt_output.x)
			cov = []
		
		else:
			self.species_index = []
			self.cp_0 = {}
			self.cp_max = {}
			self.T = []
			for species in self.unsrt:
				self.species_index.append(species)
				lim = self.unsrt[species].temp_limit
				T = self.unsrt[species].temperatures
				#print("line 1179 Optimization tool T \n " , T)
				if lim == "Low":
					self.T.extend(list(np.linspace(T[0],T[-1],5)))
				else:
					self.T.extend(list(np.linspace(T[0],T[-1],5)[1:])) #skip the common temperature
			self.T = np.asarray(self.T).flatten() #DOF = 9
			#print(self.T)
			all_species_list = []  # List 1: All species with descriptors- low and high
			key_species_list = []  # List 2: Unique species names
			paired_data_list = []  # List 3: Paired High and Low data for each species


			self.species_dict = {}
			self.zeta_dict = {}
			self.cov_dict = {}
			for species_descriptor in self.unsrt:
				all_species_list.append(species_descriptor)
				base_species = species_descriptor.split(":")[0]
				if base_species not in key_species_list:
					key_species_list.append(base_species)
				if base_species not in self.species_dict:
					self.species_dict[base_species] = {}
					self.zeta_dict[base_species] = {}
					self.cov_dict[base_species] = {}
				self.species_dict[base_species][species_descriptor.split(":")[1]] = self.unsrt[species_descriptor].nominal[0:5]
				self.zeta_dict[base_species][species_descriptor.split(":")[1]] = self.unsrt[species_descriptor].zeta_max.x
				self.cov_dict[base_species][species_descriptor.split(":")[1]] = self.unsrt[species_descriptor].cov
			
			#print(len(self.T))
			#self.init_guess = np.zeros(len(self.T[1:])*len(self.species_index))
			self.init_guess = np.array([-2.96893286,0.76861981,17.4261154,45.4912758,10.0504961,-1.50947742,1.07985437,1.65623474,-0.339644179,5.14789303,1.41980216,-2.7868245,18.5771791,6.38730047,2.03608777,0.735639342,0.635280217,4.44022129,2.46345247,1.08053651,-1.0320216,2.28972601,11.2433774,8.84643232,2.6845374,-3.32188469,-5.5823844,-4.73678754,-24.621364,4.49043001,0.109785722,-3.61280577,72.268569,37.1318507,8.58929532,4.56276155,16.72694,-20.3222704,-22.4714367,11.6492897,2.83900928,2.98787738,-35.8113613,-14.0451364,-2.11520168,11.8108703,-14.8673447,-61.017312,117.928411,27.3207054,-0.512431326,-0.395861123,14.5678042,8.11913429,2.5010311,-1.00499721,-0.540682717,-0.323527367,-0.0752015412,1.21455104,0.192446569,0.694958936,34.9679687,4.32339462,-78.2844219,-0.266273536,-0.171549093,-6.13088537,-6.90337571,5.25188327,18.8685928,346.641921,-1778.20726,3886.08529,1763.37944,-9.38066425,-32.1146073,-181.403055,-11.5461109,56.3705034,3.11977583,1.62205554,-21.3389812,-5.59264694,-0.230593311,6.90737712,-40.2357966,-12.208475,-151.828192,-23.9850608,1.09325274,-0.405419652,-8.22169336,5.77094053,1.35098526,1.10570741,4.32684794,2.39707177,1.62472607,11.7328336])
			#self.init_guess = np.ones(len(self.T)*len(self.species_index))
			cons = []
			n_vectors = len(self.init_guess)
			vector_lengths = [len(self.species_dict[vec]) for vec in self.species_dict]
			start_idx = 0
			for vec_len in vector_lengths:
				for j in range(vec_len - 1):
					# Constraint: x_vec_i[j+1] - x_vec_i[j] >= 0
					cons.append({
					'type': 'ineq',
					'fun': lambda Z, start=start_idx, idx=j: 
					Z[start + idx + 1] - Z[start + idx]
					})
				start_idx += vec_len
			bounds = tuple([(-1,1) for _ in self.init_guess ])
			
			self.theta_global = np.array([self.T/self.T,self.T,self.T**2,self.T**3,self.T**4])
			#self.theta_inv = np.linalg.inv(theta.T)
			start = time.time()
			
			if "GD" in self.opt_method:
				opt_output = minimize(self.obj_func_of_selected_PRS_thermo,self.init_guess,bounds=bounds,constraints=cons,method='SLSQP',options={"maxiter":500000})
				stop = time.time()
				final=print(f"Time taken for optimization {stop-start}")
				#opt_output = spopt.root(self._obj_function,self.init_guess,method="lm",jac = True)
				print(opt_output)
				optimal_parameters = np.asarray(opt_output.x)
			else:
				fitness_function = self.fitness_function_for_T_DIPENDENT()
				#self.init_guess = np.zeros(len(self.rxn_index))
				gene_space = [{'low': -1, 'high': 1} for _ in self.init_guess ]
				self.ga_instance = pygad.GA(num_generations=2000,
			               num_parents_mating=300,
			               fitness_func=fitness_function,
			               init_range_low=-1,
			               init_range_high=1,
			               sol_per_pop=400,
			               num_genes=len(self.init_guess),
			               crossover_type="uniform",
			               crossover_probability=0.6,
			               mutation_type="adaptive",
			               mutation_probability=(0.03, 0.008),
			               gene_type=float,
			               allow_duplicate_genes=False,
			               gene_space=gene_space,
			               keep_parents = -1,
			               save_best_solutions=True,
			               save_solutions=True,
			               stop_criteria=["reach_200"])
				
				self.ga_instance.run()
				self.ga_instance.plot_fitness(title="GA with Adaptive Mutation", linewidth=5)
				filename = 'genetic'
				self.ga_instance.save(filename=filename)
				optimal_parameters, solution_fitness, solution_idx = self.ga_instance.best_solution()
			
			#residuals,final_jac= self._obj_function(optimal_parameters)
			#icov = np.dot(final_jac.T,final_jac)
			#cov = np.linalg.inv(icov)
			#raise AssertionError("Optimization done!")
			"""
			Finding the optimal parameters
			"""
			print("<<<<<<<<<<<<<<<<FOUND BEST SOLUTION>>>>>>>>>>>>>>>>>>>>>\n")
			#print(f"{solution}")
			"""
			-----------------------------------------
			Transformation 1.0 of the optimal parameters:
			-----------------------------------------
			
				 X =  __ln(cp/cp_0)____
				   ln(cp_max/cp_0)
				
			  ln(cp) - ln(cp_0) = X*[ln(cp_max) - ln(cp_0)]
			  
			  ln(cp) = ln(cp_0) + X*[ln(cp_max) - ln(cp_0)]
				 
			-----------------------------------------
			Transformation 2.0 of the optimal parameters:
			-----------------------------------------
			
				 X =  ___cp__-__cp_0__
					cp_max - cp_0
				
			  cp - cp_0 = X*[cp_max - cp_0]
			  
			  cp = cp_0 + X*[cp_max - cp_0]
			
			
			"""
			Z_star = optimal_parameters
			V_of_Z = {}
			count = 0
			for ind,speciesID in enumerate(self.unsrt):
				if self.unsrt[speciesID].a1_star is None or np.all(self.unsrt[speciesID].a1_star) == None:
					species_name = self.unsrt[speciesID].species
					lim = self.unsrt[speciesID].temp_limit
					p_o = self.species_dict[species_name][lim]
					#print(p_o)
					zeta_max = self.zeta_dict[species_name][lim]
					cov = self.cov_dict[species_name][lim]
					Z_species = Z_star[count:count+len(p_o)]
					T_low = self.T[count:count+len(p_o)]
					#print("T_low \t", T_low)
					Cp_T = []
					for index in range(5):
						t = T_low[index]
						Theta = np.array([t/t,t,t**2,t**3,t**4])
						p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
						Cp_T.append(Theta.dot(p_))
					x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_low),species_name,self.count,tag="Low")
					count+=len(p_o)
					V_of_Z[speciesID] = x_species
					for spec in self.unsrt:
						if self.unsrt[spec].species == species_name:
							self.unsrt[spec].a1_star = Z_species
							self.unsrt[spec].a2_star = Z_species[-1]
							self.unsrt[spec].Cp_T_mid_star = Cp_T[-1]
				else:
					species_name = self.unsrt[speciesID].species
					lim = self.unsrt[speciesID].temp_limit
					p_o = self.species_dict[species_name][lim]
					zeta_max = self.zeta_dict[species_name][lim]
					cov = self.cov_dict[species_name][lim]
					Z_species = Z_star[count:count+len(p_o)-1]
					Cp_T = [self.unsrt[speciesID].Cp_T_mid_star]  ##Start with mid Cp value 1000k
					T_high = self.T[count:count+len(p_o)-1]
					for index in range(4):  ### Start from the next point after 1000 K
						t = T_high[index]
						Theta = np.array([t/t,t,t**2,t**3,t**4])
						p_ = p_o + Z_species[index]*np.asarray(np.dot(cov,zeta_max)).flatten()
						Cp_T.append(Theta.dot(p_))
					x_species = self.unsrt[speciesID].DECODER(np.asarray(Cp_T),np.asarray(T_high),species_name,self.count,tag="High")
					count+=len(p_o)-1
					V_of_Z[speciesID] = x_species
			
			string = ""
			#print(V_of_Z)
			V_star = []
			for spec in self.unsrt:
				#V_star.extend(list(V_of_Z[spec]))
				for k in V_of_Z[spec]:
					string+=f"{k},"
					V_star.append(k)
				#x_transformed.extend(temp)
				string+=f"\n"
			V_star = np.asarray(V_star)
			zeta_file = open("OPTIMIZED_ZETA.csv","w").write(string)	
			
			#########################
			### For plotting purposes
			########################
			##NEED TO ADD LINES FOR THAT
		
						
		return np.asarray(Z_star),np.asarray(V_star),cov
	
	
